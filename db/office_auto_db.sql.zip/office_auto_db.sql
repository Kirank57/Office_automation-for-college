-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 04, 2023 at 08:54 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `office_auto_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `assign_sub_details`
--

CREATE TABLE `assign_sub_details` (
  `as_id` int(100) NOT NULL auto_increment,
  `sub_id` varchar(100) NOT NULL,
  `s_id` varchar(100) NOT NULL,
  PRIMARY KEY  (`as_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `assign_sub_details`
--

INSERT INTO `assign_sub_details` (`as_id`, `sub_id`, `s_id`) VALUES
(1, '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `branch_details`
--

CREATE TABLE `branch_details` (
  `b_id` int(100) NOT NULL auto_increment,
  `b_name` varchar(100) NOT NULL,
  `b_description` varchar(100) NOT NULL,
  `b_hod` varchar(100) NOT NULL,
  `b_fees` varchar(100) NOT NULL,
  PRIMARY KEY  (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `branch_details`
--

INSERT INTO `branch_details` (`b_id`, `b_name`, `b_description`, `b_hod`, `b_fees`) VALUES
(1, 'MCA', 'Bachelors in Computer Application', 'Rajesk Patil', '28000');

-- --------------------------------------------------------

--
-- Table structure for table `completed_syllabus`
--

CREATE TABLE `completed_syllabus` (
  `cs_id` int(100) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `uploaded_date` varchar(100) NOT NULL,
  `uploaded_time` varchar(100) NOT NULL,
  `uploaded_by` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`cs_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `completed_syllabus`
--

INSERT INTO `completed_syllabus` (`cs_id`, `title`, `description`, `uploaded_date`, `uploaded_time`, `uploaded_by`, `status`) VALUES
(2, 'Chapter 1', 'Chapter 1 History and Basics', '2023-9-2', '-', '1', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `fees_details`
--

CREATE TABLE `fees_details` (
  `f_id` int(100) NOT NULL auto_increment,
  `st_id` varchar(100) NOT NULL,
  `sem` varchar(100) NOT NULL,
  `f_total` varchar(100) NOT NULL,
  `f_paid` varchar(100) NOT NULL,
  `f_p_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fees_details`
--

INSERT INTO `fees_details` (`f_id`, `st_id`, `sem`, `f_total`, `f_paid`, `f_p_date`) VALUES
(1, '1', '6th Sem', '28000', '18000', '2023-8-26');

-- --------------------------------------------------------

--
-- Table structure for table `ia_marks`
--

CREATE TABLE `ia_marks` (
  `ia_id` int(100) NOT NULL auto_increment,
  `sub_id` varchar(100) NOT NULL,
  `st_regno` varchar(100) NOT NULL,
  `ia_tmarks` int(100) NOT NULL,
  `ia_rmarks` int(100) NOT NULL,
  `udate` varchar(100) NOT NULL,
  `s_id` varchar(100) NOT NULL,
  PRIMARY KEY  (`ia_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ia_marks`
--

INSERT INTO `ia_marks` (`ia_id`, `sub_id`, `st_regno`, `ia_tmarks`, `ia_rmarks`, `udate`, `s_id`) VALUES
(1, '1', 'M1915001', 20, 16, '2023-8-26', 'kiran@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `s_qstn` varchar(100) NOT NULL,
  `s_ans` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`, `s_qstn`, `s_ans`, `status`) VALUES
('admin@office', 'admin123', 'admin', 'Who am i?', 'theadmin', 'active'),
('kiran@gmail.com', '9988776655', 'staff', 'Enter Last 4 Digits of Reg. Mobile No.', '6655', 'active'),
('rakesh@gmail.com', '9517531230', 'student', 'What is my Date of birth?', '2002-04-10', 'active'),
('sonali@gmail.com', '7418529630', 'student', 'What is my Date of birth?', '1998-10-10', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `markscard_details`
--

CREATE TABLE `markscard_details` (
  `m_id` int(100) NOT NULL auto_increment,
  `st_reg` varchar(100) NOT NULL,
  `sem` varchar(100) NOT NULL,
  `m_date` varchar(100) NOT NULL,
  `m_status` varchar(100) NOT NULL,
  PRIMARY KEY  (`m_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `markscard_details`
--

INSERT INTO `markscard_details` (`m_id`, `st_reg`, `sem`, `m_date`, `m_status`) VALUES
(1, 'M1915001', '6th Sem', '-', 'available'),
(2, 'MCA123456', '6th Sem', '-', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `notice_details`
--

CREATE TABLE `notice_details` (
  `n_id` int(100) NOT NULL auto_increment,
  `n_from` varchar(100) NOT NULL,
  `n_to` varchar(100) NOT NULL,
  `n_date` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`n_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `notice_details`
--

INSERT INTO `notice_details` (`n_id`, `n_from`, `n_to`, `n_date`, `notice`, `status`) VALUES
(1, 'Admin', '1', '2023-9-2', 'Pay Remaining fees in this week', 'Seen'),
(2, 'kiran@gmail.com', '1', '2023-9-2', 'Notice from staff', 'Seen');

-- --------------------------------------------------------

--
-- Table structure for table `quary_details`
--

CREATE TABLE `quary_details` (
  `q_id` int(100) NOT NULL auto_increment,
  `q_from` varchar(100) NOT NULL,
  `q_to` varchar(100) NOT NULL,
  `quary` varchar(100) NOT NULL,
  `uploaded_date` varchar(100) NOT NULL,
  `ans` varchar(100) NOT NULL,
  `uploaded_ans_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`q_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `quary_details`
--

INSERT INTO `quary_details` (`q_id`, `q_from`, `q_to`, `quary`, `uploaded_date`, `ans`, `uploaded_ans_date`) VALUES
(2, '1', '1', 'How can i get marks card?', '2023-9-2', 'Check status from your panel if it is available in college come and get ', '2023-9-2'),
(3, '2', '1', 'How to prepare ppt?', '2023-9-4', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `rating_details`
--

CREATE TABLE `rating_details` (
  `r_id` int(100) NOT NULL auto_increment,
  `st_id` varchar(100) NOT NULL,
  `s_id` varchar(100) NOT NULL,
  `teaching` varchar(100) NOT NULL,
  `extra_activity` varchar(100) NOT NULL,
  `performances` varchar(100) NOT NULL,
  PRIMARY KEY  (`r_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `rating_details`
--

INSERT INTO `rating_details` (`r_id`, `st_id`, `s_id`, `teaching`, `extra_activity`, `performances`) VALUES
(2, '1', '1', '4', '3', '3'),
(3, '2', '1', '4', '4', '4');

-- --------------------------------------------------------

--
-- Table structure for table `salary_details`
--

CREATE TABLE `salary_details` (
  `sal_id` int(100) NOT NULL auto_increment,
  `s_id` varchar(100) NOT NULL,
  `sal_amount` varchar(100) NOT NULL,
  `sal_date` varchar(100) NOT NULL,
  `sal_month` varchar(100) NOT NULL,
  `sal_year` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`sal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `salary_details`
--

INSERT INTO `salary_details` (`sal_id`, `s_id`, `sal_amount`, `sal_date`, `sal_month`, `sal_year`, `status`) VALUES
(2, '1', '18000', '2023-9-2', '9', '2023', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `s_id` int(100) NOT NULL auto_increment,
  `b_id` varchar(100) NOT NULL,
  `s_fname` varchar(100) NOT NULL,
  `s_lname` varchar(100) NOT NULL,
  `s_contact` varchar(100) NOT NULL,
  `s_email` varchar(100) NOT NULL,
  `s_qualification` varchar(100) NOT NULL,
  `s_designation` varchar(100) NOT NULL,
  `s_address` varchar(100) NOT NULL,
  `s_photo` varchar(100) NOT NULL,
  `s_salary` varchar(100) NOT NULL,
  PRIMARY KEY  (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`s_id`, `b_id`, `s_fname`, `s_lname`, `s_contact`, `s_email`, `s_qualification`, `s_designation`, `s_address`, `s_photo`, `s_salary`) VALUES
(1, '1', 'Kiran', 'Kage', '9988776655', 'kiran@gmail.com', 'MCA', 'Lecturer', 'Belgavi', 'user.png', '18000');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `st_id` int(100) NOT NULL auto_increment,
  `b_id` int(100) NOT NULL,
  `st_sem` varchar(100) NOT NULL,
  `st_regno` varchar(100) NOT NULL,
  `st_fname` varchar(100) NOT NULL,
  `st_lname` varchar(100) NOT NULL,
  `st_dob` varchar(100) NOT NULL,
  `st_content` varchar(12) NOT NULL,
  `st_email` varchar(100) NOT NULL,
  `st_address` varchar(100) NOT NULL,
  `st_photo` varchar(100) NOT NULL,
  PRIMARY KEY  (`st_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`st_id`, `b_id`, `st_sem`, `st_regno`, `st_fname`, `st_lname`, `st_dob`, `st_content`, `st_email`, `st_address`, `st_photo`) VALUES
(1, 1, '6th Sem', 'M1915001', 'Rakesh', 'Gali', '2002-04-10', '9517531230', 'rakesh@gmail.com', 'Belagavi', 'user.png'),
(2, 1, '6th Sem', 'MCA123456', 'Sonali', 'Patil', '1998-10-10', '7418529630', 'sonali@gmail.com', 'Near post office Belgavi', 'user.png');

-- --------------------------------------------------------

--
-- Table structure for table `subject_details`
--

CREATE TABLE `subject_details` (
  `sub_id` int(100) NOT NULL auto_increment,
  `b_id` varchar(100) NOT NULL,
  `s_sem` varchar(100) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `sub_description` varchar(100) NOT NULL,
  PRIMARY KEY  (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `subject_details`
--

INSERT INTO `subject_details` (`sub_id`, `b_id`, `s_sem`, `sub_name`, `sub_description`) VALUES
(1, '1', 'Semester 6', 'Java', 'Advance Java Theory'),
(2, '1', 'Semester 6', 'C Programming', 'C Programming'),
(3, '1', 'Semester 6', 'J2EE', 'Java Enterprises Edition');
